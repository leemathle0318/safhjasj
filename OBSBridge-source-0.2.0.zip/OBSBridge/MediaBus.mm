#import "MediaBus.h"
#import "Shared.h"
#import <CoreImage/CoreImage.h>
#import <CoreMedia/CoreMedia.h>
#include <notify.h>
#include <unistd.h>
#include <mutex>
#include <new>

namespace {
const char *names[] = {OB_BUS_NOTIFY, OB_MEDIA_HEARTBEAT, OB_MEDIA_HOOKS, OB_MEDIA_COUNTS};
int tokens[] = {-1, -1, -1, -1};
std::mutex notifications;
uint32_t channel(unsigned i, uint64_t *value, bool write) {
    std::lock_guard<std::mutex> lock(notifications);
    if (tokens[i] < 0) {
        uint32_t rc = notify_register_check(names[i], &tokens[i]);
        if (rc != NOTIFY_STATUS_OK) { tokens[i] = -1; return rc; }
    }
    if (write) return notify_set_state(tokens[i], *value);
    return notify_get_state(tokens[i], value);
}
uint64_t get(unsigned i) { uint64_t value = 0; channel(i, &value, false); return value; }
uint32_t set(unsigned i, uint64_t value) { return channel(i, &value, true); }
std::mutex stateLock;
IOSurfaceRef producerSurface;
obs::SharedMedia *producer;
CVPixelBufferRef videoBuffers[3]{};
uint32_t frameSequence = 0;
unsigned nextSlot = 0;
std::shared_ptr<OBMapping> mapping;
uint32_t mappingID = 0;
double nextLookup = 0;
NSString *producerMessage = @"共享媒体尚未初始化";
NSString *consumerMessage = @"尚未收到共享媒体 ID";
void producerNote(NSString *text) { std::lock_guard<std::mutex> lock(stateLock); producerMessage = text; }
void consumerNote(NSString *text) { consumerMessage = text; } // under stateLock
}

double OBNow(void) { return CMTimeGetSeconds(CMClockGetTime(CMClockGetHostTimeClock())); }
NSString *OBBusCreate(void) {
    if (producer) return nil;
    size_t rows = (sizeof(obs::SharedMedia) + 4095) / 4096;
    NSDictionary *properties = @{(id)kIOSurfaceWidth: @1024, (id)kIOSurfaceHeight: @(rows),
        (id)kIOSurfaceBytesPerElement: @4, (id)kIOSurfaceBytesPerRow: @4096,
        (id)kIOSurfaceAllocSize: @(rows * 4096), (id)kIOSurfacePixelFormat: @(kCVPixelFormatType_32BGRA),
        @"IOSurfaceIsGlobal": @YES};
    producerSurface = IOSurfaceCreate((__bridge CFDictionaryRef)properties);
    if (!producerSurface) { producerNote(@"IOSurfaceCreate 控制缓冲失败"); return producerMessage; }
    void *base = IOSurfaceGetBaseAddress(producerSurface);
    if (!base || IOSurfaceGetAllocSize(producerSurface) < sizeof(obs::SharedMedia) ||
        uintptr_t(base) % alignof(obs::SharedMedia)) {
        CFRelease(producerSurface); producerSurface = nullptr;
        producerNote(@"共享缓冲尺寸/地址对齐不正确"); return producerMessage;
    }
    producer = new (base) obs::SharedMedia;
    producer->initialize();
    OBBusHeartbeat();
    uint32_t rc = set(0, IOSurfaceGetID(producerSurface));
    if (rc != NOTIFY_STATUS_OK) {
        producerNote([NSString stringWithFormat:@"共享 ID 通知状态写入失败：%u；接收可独立测试", rc]);
        return producerMessage;
    }
    producerNote(@"共享控制缓冲已发布；需媒体服务确认映射成功");
    return nil;
}
void OBBusHeartbeat(void) {
    if (producer) producer->heartbeatUS.store(uint64_t(OBNow() * 1000000), std::memory_order_release);
}
void OBBusEnable(BOOL enabled) {
    if (!producer) return;
    if (!enabled && !producer->enabled.load(std::memory_order_acquire)) return;
    producer->enabled.store(0, std::memory_order_release);
    producer->generation.fetch_add(1, std::memory_order_acq_rel);
    producer->resetAudio();
    for (auto &slot : producer->video) {
        if (obs::acquireWriter(slot)) {
            slot.sequence.store(0, std::memory_order_relaxed);
            slot.dueUS.store(0, std::memory_order_relaxed);
            obs::releaseWriter(slot);
        }
    }
    OBBusHeartbeat();
    producer->enabled.store(enabled, std::memory_order_release);
}
void OBBusResetAudio(void) {
    if (producer) {
        producer->generation.fetch_add(1, std::memory_order_acq_rel);
        producer->resetAudio(); // also invalidates old video slots by epoch
    }
}
void OBBusWriteAudio(const float *samples, size_t count, double due) {
    if (producer && producer->enabled.load(std::memory_order_acquire)) producer->writeAudio(samples, count, due);
}
BOOL OBBusPublishVideo(CVPixelBufferRef source, double due) {
    if (!producer || !source || !producer->enabled.load(std::memory_order_acquire)) return NO;
    unsigned chosen = 3;
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        unsigned i = (nextSlot + attempt) % 3;
        if (obs::acquireWriter(producer->video[i])) { chosen = i; break; }
    }
    if (chosen == 3) return NO; // do not block camera consumers
    auto &slot = producer->video[chosen];
    size_t w = CVPixelBufferGetWidth(source), h = CVPixelBufferGetHeight(source);
    BOOL ok = NO;
    @try {
        CVPixelBufferRef &pixel = videoBuffers[chosen];
        if (pixel && (CVPixelBufferGetWidth(pixel) != w || CVPixelBufferGetHeight(pixel) != h)) {
            CVPixelBufferRelease(pixel); pixel = nullptr;
        }
        if (!pixel) {
            NSDictionary *attrs = @{(id)kCVPixelBufferIOSurfacePropertiesKey: @{@"IOSurfaceIsGlobal": @YES}};
            CVReturn rc = CVPixelBufferCreate(kCFAllocatorDefault, w, h, kCVPixelFormatType_32BGRA,
                (__bridge CFDictionaryRef)attrs, &pixel);
            if (rc != kCVReturnSuccess || !pixel) producerNote([NSString stringWithFormat:@"共享视频缓冲创建失败：%d", rc]);
        }
        IOSurfaceRef surface = pixel ? CVPixelBufferGetIOSurface(pixel) : nullptr;
        if (surface) {
            static CIContext *context; static dispatch_once_t once;
            dispatch_once(&once, ^{ context = [CIContext contextWithOptions:@{kCIContextUseSoftwareRenderer: @NO}]; });
            CIImage *image = [CIImage imageWithCVPixelBuffer:source];
            [context render:image toCVPixelBuffer:pixel];
            slot.surface.store(IOSurfaceGetID(surface), std::memory_order_relaxed);
            slot.generation.store(producer->generation.load(std::memory_order_acquire), std::memory_order_relaxed);
            slot.dueUS.store(uint64_t(due * 1000000), std::memory_order_relaxed);
            if (++frameSequence == 0) ++frameSequence;
            slot.sequence.store(frameSequence, std::memory_order_release);
            nextSlot = (chosen + 1) % 3;
            ok = YES;
        }
    } @catch (NSException *exception) { producerNote([@"共享视频发布异常：" stringByAppendingString:exception.name]); }
    if (!ok) slot.sequence.store(0, std::memory_order_release);
    obs::releaseWriter(slot);
    return ok;
}
NSString *OBBusProducerStatus(void) {
    std::lock_guard<std::mutex> lock(stateLock); return producerMessage;
}
std::shared_ptr<OBMapping> OBBusConsumer(void) {
    std::lock_guard<std::mutex> lock(stateLock);
    double now = OBNow();
    if (now >= nextLookup) {
        nextLookup = now + .25;
        uint64_t state = 0;
        uint32_t rc = channel(0, &state, false);
        uint32_t id = uint32_t(state);
        if (rc != NOTIFY_STATUS_OK) consumerNote([NSString stringWithFormat:@"读取共享 ID 通知失败：%u", rc]);
        else if (!id) { mapping.reset(); mappingID = 0; consumerNote(@"未收到 SpringBoard 共享 ID"); }
        else if (id != mappingID || !mapping) {
            IOSurfaceRef surface = IOSurfaceLookup(id);
            if (!surface) { mapping.reset(); mappingID = 0;
                consumerNote([NSString stringWithFormat:@"IOSurfaceLookup(%u) 失败，需检查跨进程可见性/权限", id]); }
            else {
                void *base = IOSurfaceGetBaseAddress(surface);
                size_t size = IOSurfaceGetAllocSize(surface);
                auto *data = static_cast<obs::SharedMedia *>(base);
                if (!data || uintptr_t(base) % alignof(obs::SharedMedia) || size < sizeof(obs::SharedMedia) ||
                    size > sizeof(obs::SharedMedia) + 4096 ||
                    data->magic.load(std::memory_order_acquire) != obs::BusMagic ||
                    data->version != obs::BusVersion || data->bytes != sizeof(obs::SharedMedia)) {
                    CFRelease(surface); mapping.reset(); mappingID = 0;
                    consumerNote(@"控制 IOSurface 的大小/协议/对齐不匹配");
                } else {
                    mapping = std::make_shared<OBMapping>(surface, data); mappingID = id;
                    consumerNote(@"共享控制缓冲映射成功（不代表画面/声音已替换）");
                }
            }
        }
    }
    return mapping;
}
NSString *OBBusConsumerError(void) { std::lock_guard<std::mutex> lock(stateLock); return consumerMessage; }
std::unique_ptr<OBVideoLease> OBBusCopyVideo(void) {
    auto current = OBBusConsumer();
    uint64_t now = uint64_t(OBNow() * 1000000);
    if (!current || !current->data->fresh(now)) return nullptr;
    uint32_t epoch = current->data->generation.load(std::memory_order_acquire);
    unsigned chosen = 3; uint64_t bestDue = 0;
    for (unsigned i = 0; i < 3; ++i) {
        auto &slot = current->data->video[i];
        if (!obs::acquireReader(slot)) continue;
        uint64_t due = slot.dueUS.load(std::memory_order_acquire);
        if (slot.generation.load(std::memory_order_acquire) == epoch &&
            slot.sequence.load(std::memory_order_acquire) && due <= now && now - due < 500000 && due >= bestDue) {
            if (chosen < 3) obs::releaseReader(current->data->video[chosen]);
            chosen = i; bestDue = due;
        } else obs::releaseReader(slot);
    }
    if (chosen == 3) return nullptr;
    auto &slot = current->data->video[chosen];
    uint32_t id = slot.surface.load(std::memory_order_acquire);
    IOSurfaceRef surface = id ? IOSurfaceLookup(id) : nullptr;
    CVPixelBufferRef pixel = nullptr;
    CVReturn rc = surface ? CVPixelBufferCreateWithIOSurface(kCFAllocatorDefault, surface, nullptr, &pixel) : kCVReturnError;
    if (surface) CFRelease(surface);
    if (rc != kCVReturnSuccess || !pixel || CVPixelBufferGetWidth(pixel) > 2048 ||
        CVPixelBufferGetHeight(pixel) > 2048 || CVPixelBufferGetPixelFormatType(pixel) != kCVPixelFormatType_32BGRA ||
        !current->data->fresh(now) || current->data->generation.load(std::memory_order_acquire) != epoch) {
        if (pixel) CVPixelBufferRelease(pixel);
        obs::releaseReader(slot);
        return nullptr;
    }
    return std::make_unique<OBVideoLease>(current, chosen, pixel);
}
void OBMediaHeartbeat(uint32_t hooks, uint64_t videoCalls, uint64_t audioCalls,
                      uint64_t replaced, uint64_t mixed, uint32_t failure) {
    // This health channel does not depend on writing a preferences file.
    uint32_t rc = set(1, obs::heartbeatState(uint32_t(getpid()), OBNow()));
    rc |= set(2, (uint64_t(hooks & 255) << 56) | (uint64_t(failure & 255) << 48) |
        (uint64_t(uint32_t(videoCalls) & 0xffffff) << 24) | (uint32_t(audioCalls) & 0xffffff));
    rc |= set(3, (uint64_t(uint32_t(replaced)) << 32) | uint32_t(mixed));
    if (rc != NOTIFY_STATUS_OK) {
        static uint32_t last = UINT32_MAX;
        if (rc != last) { NSLog(@"[OBSBridge] media health notify failed: %u", rc); last = rc; }
    }
}
NSString *OBMediaStatus(void) {
    uint64_t heartbeat = 0;
    uint32_t rc = channel(1, &heartbeat, false);
    if (rc != NOTIFY_STATUS_OK)
        return [NSString stringWithFormat:@"媒体心跳通知读取失败：%u，尚不能判断模块是否加载", rc];
    uint64_t hooks = get(2), counts = get(3);
    if (!obs::heartbeatFresh(heartbeat, OBNow()))
        return @"媒体模块：未收到新心跳（未加载、已停止或通知通道受限；需加载日志，不能据此认定某一种原因）";
    unsigned failure = unsigned((hooks >> 48) & 255);
    const char *reason = failure == 0 ? "无报告错误" : failure == 1 ? "未看到兼容的 BWNodeOutput 接口" :
        failure == 2 ? "控制 IOSurface 映射失败" : failure == 3 ? "没有可用共享视频帧/视频映射失败" :
        failure == 4 ? "画面格式或渲染失败" : failure == 5 ? "音频格式不支持/缺 OBS 音频" : "未知";
    return [NSString stringWithFormat:@"媒体模块：心跳正常，PID %u\n输出节点 %u；视频回调 %llu / 音频回调 %llu\n实际替换 %llu / 实际混音 %llu\n最近媒体结果：%s",
        uint32_t(heartbeat >> 32), unsigned(hooks >> 56),
        (unsigned long long)((hooks >> 24) & 0xffffff), (unsigned long long)(hooks & 0xffffff),
        (unsigned long long)(counts >> 32), (unsigned long long)uint32_t(counts), reason];
}
