# 0.2.0 检查记录（2026-10-12）

## 已实际执行

- 10 个编译单元（MediaBus、SystemHooks、Consumer、Producer、Receiver、Shortcut、ClientSB、ClientPrefs、Timeline、OBPrefs）：本机使用 Zig 0.13.0 内置 Clang、固定 Theos iPhoneOS16.5 SDK，在 arm64 iOS 15.0 目标下生成真实 Mach-O 对象文件。使用 C++17、ARC、blocks、Wall/Wextra/Werror；没有关闭弃用警告。Windows 的 SDK 文件别名被展开，独立检查工具补充 Clang 资源头与 Apple libc++ 的 nullptr_t 兼容定义；这些工具改动不进入源码包。
- 原音频时间线：重新编译并运行，Float32/Int16、交错/非交错、增益/限幅、重采样、越界、重置、并发检查通过。
- 新 SharedMedia：实际运行两个 Windows 进程，通过命名共享内存读取 PCM 和共用视频租约；检查新鲜度、停止/重置、标签与心跳计时回绕、采样率转换、共享原子并发、OBS+麦克风混音。测试通过。该测试没有调用 IOSurface，不是 iOS IPC 验收。
- 电脑回环 TCP：实际 FFmpeg 9.0.1 发送 360×640 H.264 + AAC 48 kHz MPEG-TS，接收按 137 字节拆分，重新验证 TS 同步并 ffprobe 确认两条轨道。通过。这是电脑回环，不是手机接收验收。
- 9 项源码/结构静态检查通过，覆盖角色分离、TCP 不依赖采集 Hook、固定共享配置、系统输出节点、架构和进程过滤。
- 7 项合成 deb 检查通过，覆盖缺模块/架构/错误过滤/损坏包/错误旧角色；合成包不能安装，字符串角色检查不是加载证明。
- 实际 0.2.0 ZIP 的校验、工作流 YAML/Shell/Python 解析通过；测试仅 ZIP、中文改名/子目录/大写扩展名、新旧共存、只有旧版、缺共享协议文件及路径穿越，符合预期；解压出的源码静态检查通过。

## 仍未完成

- 完整 Xcode/Theos 链接、签名、arm64e 实际构建和 GitHub 运行。
- iPhone 8 Plus / iOS 15.0.2 的 socket/listen、IOSurfaceCreate/Lookup、Darwin notify 跨进程可见性、媒体模块实际加载、私有节点签名和真实回调。
- 实际画面替换、真实麦克风与 OBS 两路声音、端到端音画同步、TikTok/其他直播 SDK、长期/压力/崩溃恢复验收。
- 旧 0.1.1 具体失败原因仍未得到手机加载/沙盒日志，不能宣称此次修改已证明其根因。

只有接收、画面、两路声音三段在手机与实际接收端通过，才能宣称完整功能可用。此版本是经过更充分本机检查的重构源码，不是已验证成品。
