#pragma once
#define OB_DOMAIN CFSTR("local.xiaoguai.obsbridge")
#define OB_NOTIFY "local.xiaoguai.obsbridge.changed"
#define OB_CONFIG @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.plist"
#define OB_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.status.plist"
#define OB_PORT 5000
#define OB_VERSION @"0.2.0"
#define OB_BUS_NOTIFY "local.xiaoguai.obsbridge.v2.bus"
#define OB_MEDIA_HEARTBEAT "local.xiaoguai.obsbridge.v2.media.heartbeat"
#define OB_MEDIA_HOOKS "local.xiaoguai.obsbridge.v2.media.hooks"
#define OB_MEDIA_COUNTS "local.xiaoguai.obsbridge.v2.media.counts"
#define OB_SHORTCUT_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.shortcut.status.plist"
