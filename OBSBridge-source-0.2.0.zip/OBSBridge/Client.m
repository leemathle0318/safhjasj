#import "Client.h"
#import "Shared.h"
#if OB_CONTROL_IN_SPRINGBOARD
#import "Receiver.h"
#endif
#include <notify.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <string.h>
#include <math.h>
#include <errno.h>

// Both control UIs and mediaserverd use this explicit shared path. A successful
// CFPreferences synchronize is not proof that this particular file was written.
static NSMutableDictionary *OBCReadConfig(void) {
    return [[NSDictionary dictionaryWithContentsOfFile:OB_CONFIG] mutableCopy] ?: [NSMutableDictionary dictionary];
}
static NSString *OBCWriteConfig(NSDictionary *config) {
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:config
        format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    if (!data) return [NSString stringWithFormat:@"无法生成控制配置：%@ (%@/%ld)",
        error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    if (![data writeToFile:OB_CONFIG options:NSDataWritingAtomic error:&error])
        return [NSString stringWithFormat:@"无法写入共享配置：%@\n%@ (%@/%ld)\n暂未发送通知。",
            OB_CONFIG, error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    if (chmod(OB_CONFIG.fileSystemRepresentation, 0644) != 0) {
        int code = errno;
        return [NSString stringWithFormat:@"配置已保存，但无法设置读取权限：%s (errno %d)\n暂未发送通知。",
            strerror(code), code];
    }
    NSDictionary *saved = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    if (![saved isEqualToDictionary:config])
        return @"共享配置写入后校验失败，暂未发送通知。请截图此提示。";
    return nil;
}

NSString *OBCWiFiIP(void) {
    struct ifaddrs *list = NULL; NSString *ip = nil;
    if (!getifaddrs(&list)) {
        for (struct ifaddrs *p = list; p; p = p->ifa_next) {
            if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET || strcmp(p->ifa_name, "en0")) continue;
            char value[INET_ADDRSTRLEN];
            if (inet_ntop(AF_INET, &((struct sockaddr_in *)p->ifa_addr)->sin_addr, value, sizeof(value)))
                ip = [NSString stringWithUTF8String:value];
        }
        freeifaddrs(list);
    }
    return ip;
}
NSString *OBCPeerIP(void) {
    id value = OBCReadConfig()[@"PCIP"];
    return [value isKindOfClass:NSString.class] ? value : @"";
}
NSString *OBCSavePeerIP(NSString *peer) {
    NSString *trimmed = [peer stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSMutableDictionary *config = OBCReadConfig();
    config[@"PCIP"] = trimmed ?: @"";
    return OBCWriteConfig(config);
}
NSString *OBCURL(void) {
    NSString *ip = OBCWiFiIP();
    return ip ? [NSString stringWithFormat:@"tcp://%@:%d", ip, OB_PORT] : nil;
}
NSString *OBCSendCommand(BOOL enabled, NSString *peer) {
    NSString *ip = OBCWiFiIP();
    NSString *trimmed = [peer stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    struct in_addr address;
    if (enabled && (!ip || !trimmed || inet_pton(AF_INET, trimmed.UTF8String, &address) != 1))
        return @"请连接 Wi-Fi，并填写 OBS 电脑的局域网 IPv4（不是手机 IP）。";
    NSMutableDictionary *config = OBCReadConfig();
    if (enabled) config[@"PCIP"] = trimmed;
    config[@"Enabled"] = @(enabled);
    config[@"BindIP"] = ip ?: @"";
    NSString *request = NSUUID.UUID.UUIDString;
    config[@"RequestID"] = request;
    config[@"RequestDate"] = [NSDate date];
    NSString *error = OBCWriteConfig(config);
    if (error) return error;
    if (notify_post(OB_NOTIFY) != NOTIFY_STATUS_OK) return @"命令已保存，但通知发送失败。";
    return nil;
}
NSString *OBCStatus(void) {
#if OB_CONTROL_IN_SPRINGBOARD
    return OBControlStatus(); // Direct status, not inferred from a missing file.
#else
    NSDictionary *status = [NSDictionary dictionaryWithContentsOfFile:OB_STATUS];
    NSDate *date = status[@"Date"];
    if (![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow) > 8)
        return @"SpringBoard 接收层没有可读的新状态，请从音量快捷菜单查看直接状态；不能据此判断媒体模块是否已加载。";
    NSString *text = status[@"Text"];
    return [text isKindOfClass:NSString.class] ? text : @"媒体服务状态格式错误。";
#endif
}
