"""Static package checks; these cannot verify private iOS media-service behavior."""
from pathlib import Path
import plistlib
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ProjectTest(unittest.TestCase):
    def test_plists(self):
        files = list(ROOT.rglob("*.plist"))
        self.assertGreaterEqual(len(files), 4)
        for path in files:
            if "work" not in path.parts and "vendor" not in path.parts:
                with self.subTest(path=path):
                    with path.open("rb") as stream:
                        self.assertIsInstance(plistlib.load(stream), dict)

    def test_system_filter(self):
        with (ROOT / "OBSBridge.plist").open("rb") as stream:
            rule = plistlib.load(stream)
        self.assertEqual(rule["Filter"], {"Executables": ["mediaserverd"]})

    def test_rootless_architectures(self):
        makefile = (ROOT / "Makefile").read_text()
        self.assertIn("ARCHS = arm64 arm64e", makefile)
        self.assertIn("THEOS_PACKAGE_SCHEME = rootless", makefile)
        self.assertIn("SystemHooks.mm", makefile)
        self.assertNotIn("Tweak.xm", makefile)

    def test_shortcut_module(self):
        with (ROOT / "OBSBridgeSB.plist").open("rb") as stream:
            rule = plistlib.load(stream)
        self.assertEqual(rule["Filter"], {"Bundles": ["com.apple.springboard"]})
        makefile = (ROOT / "Makefile").read_text()
        self.assertIn("TWEAK_NAME = OBSBridge OBSBridgeSB", makefile)
        self.assertIn("OBSBridgeSB_FILES = Shortcut.mm Client.m Producer.mm Receiver.mm MediaBus.mm", makefile)
        self.assertNotIn("Preferences", next(line for line in makefile.splitlines() if line.startswith("OBSBridgeSB_FRAMEWORKS")))
        self.assertIn("Version: 0.2.0", (ROOT / "control").read_text())

    def test_required_sources(self):
        for name in ["SystemHooks.mm", "Receiver.mm", "Receiver.h", "Shared.h",
                     "prefs/OBPrefs.m", "core/Timeline.cpp", "core/Timeline.hpp",
                     "tests/timeline_tests.cpp", "tests/shortcut_tests.cpp", "core/Shortcut.hpp",
                     "Shortcut.mm", "Client.h", "Client.m", "OBSBridgeSB.plist",
                     "Producer.mm", "Consumer.mm", "MediaBus.mm", "MediaBus.h",
                     "core/SharedMedia.hpp", "tests/shared_media_tests.cpp",
                     "tests/check_deb.py", "tests/test_deb_checker.py",
                     "scripts/build_ffmpeg.sh", "README.md", "THIRD_PARTY.md"]:
            self.assertTrue((ROOT / name).is_file(), name)

    def test_shortcut_scene_windows(self):
        source = (ROOT / "Shortcut.mm").read_text(encoding="utf-8")
        self.assertNotIn("UIApplication.sharedApplication.windows", source)
        self.assertIn("UIApplication.sharedApplication.connectedScenes", source)
        self.assertIn("for (UIWindow *window in windowScene.windows)", source)
        self.assertIn("UISceneActivationStateForegroundActive", source)
        # The scene-less fallback and original-window restoration remain intact.
        self.assertIn("initWithFrame:UIScreen.mainScreen.bounds", source)
        self.assertIn("if (isUnlocked()) [self.previousWindow makeKeyWindow]", source)

    def test_shared_config_write_contract(self):
        # Static regression only: does not simulate iOS filesystem/sandbox access.
        source = (ROOT / "Client.m").read_text(encoding="utf-8")
        engine = (ROOT / "Producer.mm").read_text(encoding="utf-8")
        self.assertNotIn("CFPreferencesSetAppValue", source)
        self.assertNotIn("CFPreferencesAppSynchronize", source)
        self.assertIn("writeToFile:OB_CONFIG options:NSDataWritingAtomic error:&error", source)
        self.assertIn("[saved isEqualToDictionary:config]", source)
        self.assertIn("chmod(OB_CONFIG.fileSystemRepresentation, 0644) != 0", source)
        self.assertIn("dictionaryWithContentsOfFile:OB_CONFIG", engine)
        command = source.split("NSString *OBCSendCommand(", 1)[1].split("NSString *OBCStatus(", 1)[0]
        for key in ("PCIP", "Enabled", "BindIP", "RequestID", "RequestDate"):
            self.assertIn(f'config[@"{key}"]', command)
        self.assertLess(command.index("OBCWriteConfig(config)"), command.index("if (error) return error;"))
        self.assertLess(command.index("if (error) return error;"), command.index("notify_post(OB_NOTIFY)"))
        header = (ROOT / "Client.h").read_text(encoding="utf-8")
        self.assertIn("NSString *OBCSavePeerIP", header)
        prefs = (ROOT / "prefs/OBPrefs.m").read_text(encoding="utf-8")
        self.assertIn("NSString *error = OBCSavePeerIP(value)", prefs)

    def test_receiver_does_not_depend_on_capture_hooks(self):
        makefile = (ROOT / "Makefile").read_text()
        media_files = next(line for line in makefile.splitlines() if line.startswith("OBSBridge_FILES"))
        self.assertIn("Consumer.mm MediaBus.mm", media_files)
        self.assertNotIn("Receiver.mm", media_files)
        source = (ROOT / "Receiver.mm").read_text(encoding="utf-8")
        self.assertNotIn("videoHook", source)
        self.assertNotIn("audioHook", source)
        self.assertIn('networkError(e, g, "bind", code)', source)
        self.assertIn('networkError(e, g, "listen", code)', source)
        self.assertIn("engine().bytes +=", source)
        client = (ROOT / "Client.m").read_text(encoding="utf-8")
        self.assertIn("return OBControlStatus()", client)

    def test_system_node_and_shared_protocol(self):
        hooks = (ROOT / "SystemHooks.mm").read_text(encoding="utf-8")
        self.assertIn('objc_getClass("BWNodeOutput")', hooks)
        self.assertIn('sel_registerName("emitSampleBuffer:")', hooks)
        self.assertNotIn("BWAudioConverterNode", hooks)
        self.assertNotIn("sourceNodeWillEmitVideoSampleBuffer", hooks)
        self.assertIn("OBMediaHeartbeat", hooks)
        self.assertNotIn("writeToFile", hooks)
        bus = (ROOT / "core/SharedMedia.hpp").read_text(encoding="utf-8")
        self.assertIn("is_always_lock_free", bus)
        self.assertNotIn("std::mutex", bus.split("struct alignas(64) SharedMedia", 1)[1])
        bridge = (ROOT / "MediaBus.mm").read_text(encoding="utf-8")
        self.assertIn("slot.generation.load(std::memory_order_acquire) == epoch", bridge)
        self.assertIn("IOSurfaceLookup", bridge)


if __name__ == "__main__":
    unittest.main(verbosity=2)
